#if NET_4_0
#include "il2cpp-config.h"
#include "TimeSpan.h"

namespace il2cpp
{
namespace icalls
{
namespace mscorlib
{
namespace System
{
    bool TimeSpan::LegacyFormatMode()
    {
        NOT_IMPLEMENTED_ICALL(TimeSpan::LegacyFormatMode);
        IL2CPP_UNREACHABLE;
        return false;
    }
} // namespace System
} // namespace mscorlib
} // namespace icalls
} // namespace il2cpp
#endif
